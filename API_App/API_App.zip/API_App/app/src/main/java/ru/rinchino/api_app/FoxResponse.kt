package ru.rinchino.api_app

data class FoxResponse(val image: String)
